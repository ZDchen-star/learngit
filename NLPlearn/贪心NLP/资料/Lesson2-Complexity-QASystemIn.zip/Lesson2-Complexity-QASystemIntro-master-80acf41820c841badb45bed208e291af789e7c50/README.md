### 课程内容
- 归并排序
- 递归式的算法复杂度计算
- Master's theorem
- Fib数列计算，空间复杂度，时间复杂度
- P,NP,NPC,NPHARD问题介绍
- QA问答系统介绍
